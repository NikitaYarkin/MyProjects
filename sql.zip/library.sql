drop database if exists  library;
create database if not exists library;
use library;

create table if not exists readers (
id int primary key auto_increment,
first_name varchar(50) not null,
last_name varchar(50) null,
sex varchar(1),
age int,
email varchar(30)  null,
phone varchar(30) not null,
registration_date  datetime not null default now()

);

create table if not exists autors
(
id int primary key auto_increment,
first_name varchar(50) not null,
last_name varchar(50) null,
birhtday  datetime not null 
);

create table if not exists books
(
id int primary key auto_increment,
autor_id int,
title varchar(50) not null,
product_date  datetime,
publisher varchar(20),
foreign key (autor_id) references autors(id)
);




create table if not exists favourite_books
(
readers_id int,
books_id int,
primary key (readers_id, books_id),
foreign key (readers_id) references readers(id),
foreign key (books_id) references books(id)
);

create table if not exists orders
(
id int primary key auto_increment,
order_datetime  datetime not null default now(),
readers_id int,
foreign key (readers_id) references readers(id)
  );



create table if not exists orders_books
(
orders_id int,
books_id int,
primary key (orders_id,books_id),
foreign key (orders_id) references orders(id),
foreign key (books_id) references books(id)
 
);

create table if not exists libraries
(
id int primary key auto_increment,
title varchar(50) not null,
address varchar(70) ,
working_house varchar(10) 
);

create table if not exists libraries_books
(
libraries_id int,
books_id int,
primary key (libraries_id,books_id),
foreign key (libraries_id) references libraries(id),
foreign key (books_id) references books(id)
);


insert into readers(first_name,last_name,phone,sex,age) values
('Вася','Пупкин',555,'m','18'),
('Иван','Петров',1234,'m','28'),
('Маша','Иванова',3434,'f','16')
;

insert into autors(first_name,last_name,birhtday) values
('Александр','Пушкин','1799-06-06'),
('Эрнест','Хэмингуэй','1899-07-27');
;

insert into books(autor_id,title,product_date ) values
(1,'Капитнаская дочка','1836-01-01'),
(1,'Пиковая дама','1833-11-01'),
(2,'Прощай оружие','1929-04-01')
;

insert into libraries(title,address ) values
('Маяковка','Санкт-Петербург'),
('Ленинка','Москва')
;

insert into  libraries_books values
(1,1),
(1,2),
(2,1);


-- select * from readers;
-- select * from autors;
-- select * from books;
-- select * from libraries;
-- select * from  libraries_books;

-- select first_name,age from readers where age >17; -- Этот запрос выведет всех читателей старше 17 лет.

-- SELECT * FROM readers WHERE sex = 'm' AND age > 25; -- Этот запрос выведет всех мужчин, возраст которых старше 25 лет.

-- SELECT readers.first_name, books.title 
-- FROM readers
-- JOIN favourite_books ON favourite_books.readers_id = readers.id
-- JOIN books ON favourite_books.books_id = books.id;   -- Этот запрос вернет имена читателей и названия их любимых книг.

-- SELECT readers.first_name, libraries.title 
-- FROM readers
-- JOIN orders ON orders.readers_id = readers.id
-- JOIN libraries ON orders.libraries_id = libraries.id; -- Этот запрос вернет имена читателей и названия библиотек, в которых они сделали заказы.

-- SELECT CONCAT(first_name, ' ', last_name) AS full_name FROM readers; -- Этот запрос вернет полное имя каждого читателя, объединяя его имя и фамилию.

-- SELECT autor_id, COUNT(*) as total_books 
-- FROM books
-- GROUP BY autor_id
-- ORDER BY total_books DESC; -- Этот запрос вернет количество книг, написанных каждым автором, сгруппированными по автору и отсортированными по убыванию.

-- SELECT autor_id, COUNT(*) as total_books 
-- FROM books
-- WHERE product_date > '1900-01-01'
-- GROUP BY autor_id
-- HAVING total_books > 2; -- Этот запрос вернет количество книг, написанных каждым автором после 1900 года и имеющих более 2 книг, сгруппированными по автору.
